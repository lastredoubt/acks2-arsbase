import { OSRIC } from '../config.js';
import * as diceManager from "../dice/dice.js";
import * as utilitiesManager from "../utilities.js";
import * as dialogManager from "../dialog.js";
import * as debug from "../debug.js"

export function addTradeButton(app, html) {
    // console.log("item-browser.js addBrowserButton", { app, html })
    if (app.options.id == "compendium" || app.options.id == "items") {
        const browserButton = $(`<button class='item-browser' title='Browse Items'> ` +
            `<i class='fas fa-shopping-basket'></i>` +
            `Item Browser` +
            `</button>`);

        browserButton.click(function (env) {
            console.log("item-browser.js browserButton", { env })
            if (!game.osric.ui.itembrowser) {
                ui.notifications.warn(`Item browser is loading data...please wait.`);
                return;
            }
            if (game.osric.ui.itembrowser._getTargetOfItem()) {
                game.osric.ui.itembrowser.render(true);
            } else {
                ui.notifications.error(`Must control an actor or select token to aquire items.`);
            }

        });

        html.find(".header-actions").append(browserButton);
    }
}
export class OSRICCharacterTrade extends Application {
    constructor(app) {
        super(app)
    }

    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            resizable: true,
            minimizable: true,
            id: "item-browser-sheet",
            classes: ["osric", "item-browser"],
            title: "Trade",
            template: "systems/osric/templates/apps/character-trade.hbs",
            width: 700,
            height: 830,
            scrollY: [".filter-list", ".item-list"],
        });
    }

    /** @override */
    async getData() {
        const data = await super.getData();

        data.this = this;
        data.filters = this.filters;
        data.game = game;
        data.config = OSRIC;

        data.items = this.items;
        // filter item list by source
        if (this.filters.source && this.filters.source !== 'All') {
            data.items = data.items.filter((i) => {
                return (
                    (this.filters.source === 'World' && !i.pack) ||
                    (i.pack === this.filters.source)
                );
            });
        }
        // filter item list by name
        data.items = data.items.filter((i) =>
            i.isIdentified &&
            i.type === this.filters.type &&
            ((!this.filters.general.name) || (i.name.match(new RegExp(`${this.filters.general.name}`, 'ig'))))
        );

        // if this item type has special filters...
        if (this.filters[this.filters.type]) {
            const specialFilters = this.filters[this.filters.type];
            for (const filter of Object.keys(specialFilters)) {
                const value = String(specialFilters[filter].value);
                // console.log("item-browser.js getData", { filter, value })
                if (value) {
                    data.items = data.items.filter(i => {
                        const dataValue = getProperty(i.system, filter);
                        return (dataValue && String(dataValue)?.match(new RegExp(`${value}`, 'ig')));
                    });
                }

            }
        }
        // end special filters

        const sourceList = ['All', 'World'];
        const sources = this.items.filter(i => i.pack).forEach(m => { if (!sourceList.includes(m.pack)) sourceList.push(m.pack) });
        data.sourceList = sourceList;
        // console.log("item-browser.js getData", { data })
        return data;
    }

    /** @override */
    activateListeners(html) {
        super.activateListeners(html);


        html.find('.filter-item-type').change((event) => this._searchGeneral(event));
        html.find('.filter-name').change((event) => this._searchGeneral(event));
        html.find('.filter-source').change((event) => this._searchGeneral(event));

        html.find('.filter-search').click((event) => this._performSearch(event));

        // add listeners for the specific fields
        for (const tag of game.system.documentTypes.Item) {
            if (this.filters[tag]) {
                const specialFilters = this.filters[tag];
                for (const filter of Object.keys(specialFilters)) {
                    const nodotsFilter = filter.replace(/\./g, '_');
                    html.find(`.filter-field-${nodotsFilter}`).change((event) => this._performSearch(event));
                }
            }

        }
        html.find('.item-take').click((event) => this._itemTake(event));
        html.find('.item-buy').click((event) => this._itemBuy(event));

        html.find('.item-edit').click(async (ev) => {
            const li = $(ev.currentTarget).parents(".item");
            const itemId = li.data("id");
            const itemPack = li.data("pack");
            let item;
            if (itemPack && itemId) {
                item = await game.packs.get(itemPack).getDocument(itemId);
            } else {
                item = game.items.get(itemId);
            }
            if (!item) {
                ui.notifications.error(`Item ${itemId} cannot be found in inventory.`)
                return;
            }
            item.sheet.render(true);
        });
    }

    /** @override to add item population */
    async _render(force = false, options = {}) {

        let worldItems = [];
        // const packItems = await utilitiesManager.getPackItems('Item', game.user.isGM);
        if (!game?.osric?.library?.packs?.items) {
            ui.notifications.warn(`Item browser is loading data...please wait.`);
            return;
        }
        const packItems = game.osric.library.packs.items;
        // console.log("item-browser.js _render", { packItems });

        if (game.user.isGM) {
            worldItems = game.items.contents;
        } else {
            worldItems = game.items.contents.filter(i => i.permission > 1);
        }
        this.items = worldItems.concat(packItems);
        this.items.sort(utilitiesManager.sortByRecordName);
        await super._render(force, options);
    }

    _searchGeneral(event) {
        // console.log("item-browser.js _searchGeneral", { event }, this)
        event.preventDefault();
        const element = event.currentTarget;
        const filterFields = element.closest('.filter-fields');

        const itemFilter = filterFields.querySelector('select[name="item-type"]')?.value;
        const sourceFilter = filterFields.querySelector('select[name="filter-source"]')?.value;
        const nameFilter = filterFields.querySelector('input[name="filter-name"]')?.value;

        if (itemFilter) {
            this.filters.type = itemFilter;
            this.filters.source = sourceFilter;
            this.filters.general.name = nameFilter;
            this.render();
        }
    }

    /**
     * 
     * Apply current filters to item list
     * 
     * @param {*} event 
     */
    _performSearch(event) {
        console.log("item-browser.js _performSearch", { event }, this)
        event.preventDefault();
        const element = event.currentTarget;
        const filterFields = element.closest('.filter-fields');

        //special filters
        if (this.filters[this.filters.type]) {
            for (const filter of Object.keys(this.filters[this.filters.type])) {
                const nodotsFilter = filter.replace(/\./g, '_');
                const value = filterFields.querySelector(`input[name="filter-field-${nodotsFilter}"]`)?.value;
                this.filters[this.filters.type][filter].value = value;
            }
            // console.log("item-browser.js _performSearch ==>", this.filters[this.filters.type])
        }
        //

        this.render();
    }

    //** take a item */
    _itemTake(event) {
        // console.log("item-browser.js _itemTake", { event }, this)
        this._itemAquire(false, event)
    }
    //** buy a item */
    _itemBuy(event) {
        // console.log("item-browser.js _itemBuy", { event }, this)
        this._itemAquire(true, event)
    }
    async _itemAquire(buy, event) {
        event.preventDefault();
        const itemId = event.currentTarget.closest(".item").dataset.id;
        const pack = event.currentTarget.closest(".item").dataset.pack;
        console.log("item-browser.js _itemAquire", { pack, itemId })
        let item;
        if (pack) {
            console.log("item-browser.js _itemAquire 1", { pack, itemId })
            // item = await game.packs.get(pack).get(itemId);
            // after some period of time the "loaded" packs for remote users don't show any longer, this forces it.
            item = await game.packs.get(pack).getDocument(itemId);
        } else {
            console.log("item-browser.js _itemAquire 2", { pack, itemId })
            item = game.items.get(itemId);
        }

        console.log("item-browser.js _itemAquire 3", { item, buy })
        if (item) {
            this._aquireItem(item, buy);
        } else {
            ui.notifications.error(`Unable to find item ${pack ? pack : ''} ${itemId}`);
        }
    }

    //** get actor to place item on */
    _getTargetOfItem() {
        const token = canvas.tokens.controlled?.[0];
        let actor = game.user.character;
        // console.log("item-browser.js _getTargetOfItem", { token, actor })
        if (token && token.isOwner) {
            actor = token.actor;
        }
        return actor;
    }
    /**
     * 
     * Take or purchase a item
     * 
     * @param {*} item 
     * @param {Boolean} purchase 
     * @returns 
     */
    async _aquireItem(item, purchase) {
        console.log("item-browser.js _aquireItem", { item, purchase })
        if (item) {
            const actor = this._getTargetOfItem();
            if (actor) {

                const count =
                    ['item', 'container', 'potion', 'weapon'].includes(item.type) ?
                        await dialogManager.dialogQuantity(0, 10000, 1, `${purchase ? 'Buy' : 'Take'} how many ${item.name}?`, `Aquire Item`, `${purchase ? 'Buy' : 'Take'}`, 'Cancel')
                        : 1;
                if (count && count > 0) {
                    if (purchase) {

                        console.log("item-browser.js _aquireItem", { count })

                        //TODO: apply margin value? discount/overcharge?
                        const price = (item.system.cost.value * count);
                        const currency = item.system.cost.currency;
                        const purse = parseInt(actor.system.currency[currency]);
                        if (purse < price) {
                            ui.notifications.error(`${actor.name} cannot afford ${price} ${currency} for ${count} ${item.name}`);
                            return;
                        } else {
                            const newPurse = purse - price;
                            await actor.update({ [`system.currency.${currency}`]: newPurse });
                        }
                    }
                    const itemData = item.toObject();
                    itemData.system.quantity = count;
                    const itemAquired = await actor.createEmbeddedDocuments("Item", [itemData]);
                    console.log("item-browser.js _aquireItem", { itemAquired })
                    utilitiesManager.chatMessage(ChatMessage.getSpeaker({ actor: actor }), `Aquired Item`, `${actor.name} ${purchase ? 'Bought' : 'Took'} ${count} ${itemAquired[0].name}.`, itemAquired[0].img, game.user.isGM ? 'gmroll' : '');
                    ui.notifications.info(`${actor.name} aquired ${count} ${itemAquired[0].name}.`);
                }

            } else {
                ui.notifications.error(`Must control an actor or select token to aquire items.`);
            }
        }
    }

}